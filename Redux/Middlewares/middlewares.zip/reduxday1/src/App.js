import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        PLEASE OPEN CONSOLE WINDOW TO CHECK OUTPUT
      </div>
    );
  }
}

export default App;
