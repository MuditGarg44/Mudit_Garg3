import React, { Component } from 'react';
import './App.css';
import ProductsHeader from "./components/ProductsHeader/ProductsHeader"
import ProductList from "./components/productlist/productlist";
import CartHeader from "./components/CartHeader/CartHeader";
import CartlistHeader from "./components/CartHeader/CartlistHeader"
import CartList from "./components/cartlist/Cartlist";
import NetAmount from "./components/NetAmount/NetAmount"
import { connect } from 'react-redux';

import {addtocart,increaseCount,decreaseCount,deleteItem} from "./actions/actioncart"

class App extends Component {
  // constructor(props)
  // {
  //   super(props);
  //   this.state = initialState;
  // }

  addtocart = (id) => {
    // console.log(products.find(index => index.id==id))
    // console.log(products.map(index => index.id==id? console.log(index):0));
    this.props.addtocart(this.props.products.find(index => index.id === id));
  }
  increaseCount = (id) => {
    this.props.increaseCount(this.props.cart.find(index => index.id === id));
  }
  decreaseCount = (id) => {
    this.props.decreaseCount(this.props.cart.find(index => index.id === id));
  }
  deleteItem = (id) => {
    this.props.deleteItem(this.props.cart.find(index => index.id === id));
  }



  render() {
    console.log(this.props);
    const {products,cart} = this.props;
    // console.log(products);
    return (
      <div className="App">
        <section className="productSection">
        <ProductsHeader/>
        <div className="productItems">
        {products.map((item,id)=> <ProductList item={item} key={id} id={item.id} addtocart={this.addtocart} />)}
        </div>
        </section>
        <section className="cartSection">
          <CartHeader />
          <div className="cartWrapper">
            <CartlistHeader/>
            <div className="cartitemlist">
              {cart.map((item,id)=><CartList item={item} key={id} increaseCount={this.increaseCount} decreaseCount={this.decreaseCount} deleteItem={this.deleteItem}/>)} 
            </div>
            
            <NetAmount cart={cart} />
          </div>
        </section>
        
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  // console.log(state);
   return {products:state.Productreducer.products, cart:state.Cartreducer.cart}
};
const mapDispatchToProps = {
  addtocart,
  increaseCount,
  decreaseCount,
  deleteItem
}

export default connect(mapStateToProps, mapDispatchToProps)(App);