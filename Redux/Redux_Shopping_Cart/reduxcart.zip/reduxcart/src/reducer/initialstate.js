import productslist from "../cartdata"


const initialState= {
    products:productslist,
    cart:[]
}
export default initialState;