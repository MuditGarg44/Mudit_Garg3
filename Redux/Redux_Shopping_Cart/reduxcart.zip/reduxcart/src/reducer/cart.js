import initialState from "./initialstate";


// const initialState= {
//     products:productslist,
//     cart:[]
// }





const reducer = (state = initialState, action) => {
    switch(action.type)
    {
        case 'ADD_TO_CART':{

            // console.log(state);
            // console.log(action);
            const cart = [...state.cart];
            if(cart.find(index =>index.id===action.product.id))
            {
                cart.forEach(index => index.id===action.product.id? index.quantity += 1: index);
                console.log(" state updation from cart " , state);
                return { cart:cart};
            }
            else
            {
                const newcartitem ={ ...action.product};
                console.log(newcartitem);
                newcartitem.quantity = 1;
                const newstate = { cart:[newcartitem , ...state.cart ]}
                console.log(newstate);
                return newstate;
            }
            
        }
        case 'INCREASE_QUANTITY':{
            console.log(action);
            const cart = [...state.cart];
            cart.forEach(index => index.id===action.cart.id? action.cart.quantity += 1: index);
            console.log(" state updation from cart " , state);
            return { cart:cart};
        }
        case 'DECREASE_QUANTITY':{
            console.log("decrease fired from cart ");
            const cart = [...state.cart];
            cart.forEach(index => index.id===action.cart.id? action.cart.quantity -= 1: index);
            console.log(" state updation from cart " , state);
            return { cart:cart};
        }
        case 'DELETE_ITEM':{
            const cart =[...state.cart.filter(index=>index.id !== action.cart.id)];
            return {cart:cart};
        }

        default: {return state}
    
    }
}

export default reducer;