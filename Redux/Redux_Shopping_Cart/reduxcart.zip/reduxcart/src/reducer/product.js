import initialState from "./initialstate"
// const initialState= {
//     products:productslist,
//     cart:[]
// }

const reducer = (state = initialState, action) => {
    switch(action.type)
    {
        case 'ADD_TO_CART':{
            // console.log(state);
            state.products.forEach(p=> p.id===action.product.id?p.quantity-=1:p );
            const newstate = { products:state.products}
            console.log(newstate);
            return newstate;
        }
        case 'INCREASE_QUANTITY':{
            console.log(state);

            const products = [...state.products];
            // console.log(action);
            products.forEach(index => index.id===action.cart.id? index.quantity -= 1: index);
            console.log("state updation from products " , state);   
            return {products};
        }
        case 'DECREASE_QUANTITY':{
            const products = [...state.products];
            products.forEach(index => index.id===action.cart.id? index.quantity += 1: index);
            console.log("state updation from products " , state);   
            return {products};
        }
        case 'DELETE_ITEM':{
            const products =[...state.products];
            products.forEach(index=>index.id===action.cart.id?index.quantity+=action.cart.quantity:index);
            // const products = state.products.map(index=>index.id===action.cart.id?index.quantity+=action.cart.quantity:index);
            console.log(products);
            return {products:products};
        }
        default: {return state}
    
    }
}

export default reducer;