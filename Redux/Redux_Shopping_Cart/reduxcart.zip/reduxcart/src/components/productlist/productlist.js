import React, { Component } from 'react';
import "./productlist.css"

 export default class Productlist extends Component
{
    render() {
        const {id,name,quantity,image,price} = this.props.item;
        if(quantity>0){
            return (
                <section className="productbox">
                    
                   <img src={image}/>
                    <h4>{name}</h4>
                    <div className="price">{price}$</div>
                    <div className="stock">In Stock ({quantity})</div>
                    <div>
                        <button type="button" className="addbtn" onClick={()=>this.props.addtocart(id)}>Add to Cart</button>
                    </div> 
                </section>
           );
        } 
        else
        {
            return (
                <section className="productbox">
                    
                   <img src={image}/>

                        <h4>{name}</h4>
                        <div className="price">{price}$</div>
                        <div className="stock">Out of Stock</div>
                    
                    
                    <div>
                        <button type="button" className="addbtndisable" >Add to Cart</button>
                    </div> 
                </section>
            );
        }
        
    }
}