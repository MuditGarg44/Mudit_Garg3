import React, { Component } from 'react';
import "./CartlistHeader.css";

export default class CartlistHeader extends Component
{
    render() {

        return (
            <section>
            <ul className="listHeader">
            <li className="hname">NAME</li>
            <li className="hprice">PRICE</li>
            <li>QUANTITY</li>
            <li className="htotal">TOTAL</li>
          </ul>

          </section>
        );
    }
}