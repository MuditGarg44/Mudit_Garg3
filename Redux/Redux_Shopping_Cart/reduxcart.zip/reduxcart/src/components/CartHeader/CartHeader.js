import React, { Component } from 'react';
import "./CartHeader.css"

export default class ProductsHeader extends Component
{
   render() {
       return (
           <div className='cheader'>
            <h1>YOUR CART</h1>
            </div>
       );
   }
}