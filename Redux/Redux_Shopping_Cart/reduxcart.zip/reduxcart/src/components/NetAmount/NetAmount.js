import React, { Component } from 'react';
import "./NetAmount.css";

export default class NetAmount extends Component
{
    render() {
        const {cart} = this.props;
        console.log(cart);
        if(cart.length < 1)
        {
            return (
                <ul className="NetAmountList">
                    <li>
                       Net Payable
                    </li>
                    <li>
                       0
                    </li>
                </ul>
           );

        }
        else
        {
            return (
                <ul className="NetAmountList">
                    <li>
                       Net Payable
                    </li>
                    <li>
                       { cart.map(index=> index.price * index.quantity).reduce((accu,curr)=> accu+curr) }
                    </li>
                </ul>
           );
        }
        
    }
}