import React, { Component } from 'react';
import './Cartlist.css';
import cartdata from "../../cartdata"

export default class Cartlist extends Component
{
    render() {
        const {id,name,quantity,price} = this.props.item;
        const itemMaxquantity = cartdata.find(index =>index.id===id);
        console.log(itemMaxquantity.quantity);
        // console.log(cartdata);
        if(quantity == 0)
        {
            // (()=>{this.props.deleteItem(id)})();
            return (
                <section className="insideList">
                    <div className="lname">{name}</div>
                    <div className="lprice">{price}</div>
                    <div className="lquantity">{quantity}</div>
                    <div className="ltotal">{price*quantity}</div>
                    <div className="plus" onClick={()=>this.props.increaseCount(id)}><i className="fas fa-plus-circle"></i></div>
                    <div className="minus" ><i className="fas fa-minus-circle"></i></div>
                    <div className="cross" onClick={()=>this.props.deleteItem(id)}><i className="fas fa-times-circle"></i> </div>
                </section>
           );
        }
        else if(itemMaxquantity.quantity<1)
        {
            return (
                <section className="insideList">
                    <div className="lname">{name}</div>
                    <div className="lprice">{price}</div>
                    <div className="lquantity">{quantity}</div>
                    <div className="ltotal">{price*quantity}</div>
                    <div className="plus"><i className="fas fa-plus-circle"></i></div>
                    <div className="minus" onClick={()=>this.props.decreaseCount(id)}><i className="fas fa-minus-circle"></i></div>
                    <div className="cross" onClick={()=>this.props.deleteItem(id)}><i className="fas fa-times-circle"></i> </div>
                </section>
           );
        }
        else
        {
            return (
                <section className="insideList">
                    <div className="lname">{name}</div>
                    <div className="lprice">{price}</div>
                    <div className="lquantity">{quantity}</div>
                    <div className="ltotal">{price*quantity}</div>
                    <div className="plus" onClick={()=>this.props.increaseCount(id)}><i className="fas fa-plus-circle"></i></div>
                    <div className="minus" onClick={()=>this.props.decreaseCount(id)}><i className="fas fa-minus-circle"></i></div>
                    <div className="cross" onClick={()=>this.props.deleteItem(id)}><i className="fas fa-times-circle"></i> </div>
                </section>
           );
        }
    }
}