import React, { Component } from 'react';
import "./ProductsHeader.css"

export default class ProductsHeader extends Component
{
   render() {
       return (
           <div className='pheader'>
            <h1>PRODUCTS</h1>
            </div>
       );
   }
}