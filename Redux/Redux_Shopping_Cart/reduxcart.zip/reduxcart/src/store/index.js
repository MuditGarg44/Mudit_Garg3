import {createStore,combineReducers} from "redux";
import Productreducer from "../reducer/product";
import Cartreducer from "../reducer/cart";
import middleware from "../middleware/handlemiddleware"

const reducers = combineReducers({
    Productreducer,
    Cartreducer
  });

export const store = createStore(reducers,middleware)