import {applyMiddleware} from "redux";

const handlemiddleware = store => next => action => {
    // console.log(action);
    next(action);   
}
export default  applyMiddleware(handlemiddleware);