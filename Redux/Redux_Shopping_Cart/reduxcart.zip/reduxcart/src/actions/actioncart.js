export const addtocart = (product) =>
({
    type:"ADD_TO_CART", product
});

export const increaseCount= (cart) =>
({
    type:"INCREASE_QUANTITY" , cart
});

export const decreaseCount= (cart) =>
({
    type:"DECREASE_QUANTITY" , cart
});
export const deleteItem= (cart) =>
({
    type:"DELETE_ITEM" , cart
});

// export default addtocart;