import React, { Component } from 'react';
import PropTypes from "prop-types";

export default (Wrapped) => {
    return class HOC extends Component 
    {
        constructor(props) {
            super(props);

    }
    static contextTypes = {
        username: PropTypes.string,
        password: PropTypes.string,
        isAuth: PropTypes.bool
      }
      
 
        render() {
            return (
                <Wrapped {...this.props} username={this.context.username} password={this.context.password} isAuth={this.context.isAuth}/>)
        }
    }
}
