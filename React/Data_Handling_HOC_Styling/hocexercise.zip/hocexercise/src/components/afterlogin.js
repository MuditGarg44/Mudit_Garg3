import React, { Component } from 'react';
import HOC from "../inject";
import inject from '../inject';

class After extends Component
{
    render() {
        return (
             <section>
                 {console.log(this.props.isAuth)}
                 <p>Following data is received from HOC, not directly as props from parent Component</p>
                 <p>user name is {this.props.username} </p>
                 <p> password is {this.props.password}</p>
                 <p> is logged in?    <b>{this.props.isAuth.toString()}</b></p>
             </section>
        );
    }
}
export default inject(After);