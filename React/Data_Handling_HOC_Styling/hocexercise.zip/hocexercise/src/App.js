import React, { Component } from 'react';
import After from "./components/afterlogin";
import Login from "./components/Login/login"
import PropTypes from "prop-types";
import {
  BrowserRouter as Router,
  Route,
  Redirect,
  Link
} from "react-router-dom";
import HOC from "./inject";
import './App.css';
import inject from './inject';

class App extends Component {
  static childContextTypes = {
    username : PropTypes.string,
    password : PropTypes.string,
    isAuth : PropTypes.bool
  }
  getChildContext(){

    return  {
      username : this.state.username,
    password : this.state.password,
    isAuth : this.state.isAuth
    }
  }
  constructor()
  {
    super();
    this.state= {
      username:"admin",
      password:"admin",
      isAuth:false
    }
  }
  handleSubmit = (event,data) =>
  {
    event.preventDefault();
    if (this.state.username === data.username && this.state.password === data.password )
    {
      this.setState({
        isAuth: true
      });
    } else {
      this.setState({
        isAuth: false
      });
    }
    console.log("runs");
    console.log(this.state.isAuth);
  }
  render() {
    return (
      <div className="App">

       <Router>

       <Route
        exact
        path="/"
        render={()=> <Login handleSubmit={this.handleSubmit} isAuth={this.state.isAuth}/>}/>
          <Route
            path="/afterlogin"
            component={After}
          />

       </Router>
       
      </div>
    );
  }
}

export default inject(App);
