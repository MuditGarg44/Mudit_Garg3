import React, { Component } from 'react';
import './Home.css';

class Home extends Component
{
    render() {
        return (
             <h1>This is Home page, go to Login page to continue</h1>
        );
    }
}
export default Home;