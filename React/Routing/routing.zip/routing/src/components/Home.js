import React, { Component } from 'react';

class Home extends Component
{
    render()
    {
        return(
            <p> THIS IS HOME PAGE, PLEASE CLICK ON NAVIGATION LINKS AT TOP RIGHT</p>
        )
    }
}
export default Home;